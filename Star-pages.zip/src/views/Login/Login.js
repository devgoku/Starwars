import React, { Component } from "react";
import axios from "axios";

import {
  Container,
  Row,
  Card,
  Col,
  CardBody,
  CardGroup,
  Form,
  InputGroup,
  Input,
  Button
} from "reactstrap";

class Login extends Component {
  constructor() {
    super();
    this.state = {
      username: null,
      password: null,
      errroMsg : null
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  onSubmit(e) {
    e.preventDefault();
    const user = {
      username: this.state.username,
      password: this.state.password,
    };

    this.loginUser(user, this.props.history);
  }

  loginUser = (userData, history) => {
    axios
      .get("https://swapi.co/api/people/")
      .then(res => {
        var login = res.data.results.find(val => {
          return (
            val.name === userData.username &&
            val.birth_year === userData.password
          );
        });

        if (login !== undefined) {
          this.setState({ errroMsg: null });
          localStorage.setItem("user_logged_in", true);
          localStorage.setItem("username", userData.username);
          history.push("/dashboard");
        } else {
          this.setState({ errroMsg: "Wrong Credentials" });
          return;
        }
      })
      .catch(err => console.log(err));
  };

  componentDidMount() {
    if (localStorage.getItem("user_logged_in") === "true") {
      this.props.history.push("/dashboard");
    }
  }
  render() {
    let error = null;
    if(this.state.errroMsg) {
      error = <p style={{color:'red'}}>{this.state.errroMsg}</p>
    } 
    
    return (
      <div className="app flex-row align-items-center">
        <Container>
          <Row className="justify-content-center">
            <Col md="8">
              <CardGroup>
                <Card className="p-4">
                  <CardBody>
                    <Form onSubmit={this.onSubmit}>
                      <h1>Star Wars Login</h1>
                      {error}
                      <InputGroup className="mb-3">
                        <Input
                          type="text"
                          placeholder="Username"
                          autoComplete="username"
                          name="username"
                          value={this.state.username}
                          onChange={this.onChange}
                        />
                      </InputGroup>
                      <InputGroup className="mb-4">
                        <Input
                          type="password"
                          name="password"
                          placeholder="Password"
                          autoComplete="current-password"
                          value={this.state.password}
                          onChange={this.onChange}
                        />
                      </InputGroup>
                      <Row>
                        <Col xs="6">
                          <Button color="primary" className="px-4">
                            Login
                          </Button>
                        </Col> 
                      </Row>
                    </Form>
                  </CardBody>
                </Card>
              </CardGroup>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Login;
