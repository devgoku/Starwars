import React, { Component } from "react";
import { Container, Row, Col, ListGroup, ListGroupItem } from "reactstrap";
import Search from "./Search";
import axios from "axios";

class Dashboard extends Component {
  constructor(props) {
    super(props);

    this.state = {
      planetData: null,
      searchText: null,
      loading: false,
      searchCount: 0,
      limitExceeded: false,
      canSearch: null,
      countDown: 59,
      disabled:false
    };
   //   this.onSearchHandler = this.onSearchHandler.bind(this);
  }


  onSearchHandler= (event) => {
    this.setState({loading: true, searchText: event.target.value }, () => {
    //  console.log(this.state.loading);
      if (this.state.searchText) {       
        this.searchPopulation(this.state.searchText);
      } else {
        this.setState({ loading: false, planetData: null });
      }
    });
  };

  componentDidMount(){
    if (localStorage.getItem("user_logged_in") !== "true") {
      this.props.history.push("/login");
    }
  }
 
  searchPopulation = (searchData) => {
  
    return axios
      .get("https://swapi.co/api/planets/")
      .then(res => {
         return res.data.results
          .filter((planet) => {
            if (planet.name.search(searchData) > -1) {
              return planet;
            } 
            return false;
          })
          .sort((a, b) => {
            return a.population - b.population;
          })
      }).then(searchPlanets => {
       // console.log(searchPlanets);
        if(localStorage.getItem('username') !== 'Luke Skywalker'){
          this.setState({
              searchCount: this.state.searchCount + 1
           },()=>{
            if(this.state.searchCount > 3){
              this.setState({
                limitExceeded : true, 
                disabled:true, 
                loading: false, 
                canSearch: 'You can search 15 times in a minute.' 
              }, () => {
                this.resetLimit();  
              });  
               return
            }
           });
         }
        if (searchPlanets.length > 0) {
          this.setState({ loading: false, planetData: searchPlanets });
        } else {
          this.setState({ loading: false, planetData: null });
        }
      }).catch(err => console.log(err));
  };


  resetLimit = () => {
   this.timer =  setInterval(() => this.tick(),1000);
      setTimeout(
        () => {
          this.setState({
            searchCount: 0, 
            limitExceeded: false,
            canSearch: 'You can search again',
            disabled:false,
            countDown:59
          },()=>{
            //console.log('clear....');
            clearInterval(this.timer);
          });
        },1000 * 60)
  }
  
  tick = () => {
    this.setState({
      countDown: this.state.countDown - 1
    });
  }

componentWillUnmount(){
  clearInterval(this.timer);
}

  render() {
    
   let list = <ListGroupItem>No Planet</ListGroupItem>;

    if (this.state.planetData) {
      list = this.state.planetData.map((planet,index) => {
        return (
          <ListGroupItem style={{fontSize: ( index * 2 ) + 12 +'px' }} key={planet.name}>
            {planet.name} : {planet.population}
          </ListGroupItem>
        );
      });
    } 

    if(this.state.loading){
        list =  <div className="animated fadeIn pt-1 text-center"> Loading... </div>
        
    }
    console.log('when Check '+this.state.searchCount);
    if(this.state.searchCount > 15 && localStorage.getItem('username') !== 'Luke Skywalker')
    {
      
      list = <div className="animated fadeIn pt-1 text-center" style={{color:'red'}}> {this.state.canSearch} Time Left: {this.state.countDown}</div>
    }

    if(this.state.searchCount === 0 && localStorage.getItem('username') !== 'Luke Skywalker')
    {
      list = <div className="animated fadeIn pt-1 text-center" style={{color:'green'}}> {this.state.canSearch}  </div>
    }


    return (
      <Container>
        <Search changes={this.onSearchHandler} disabled={this.state.disabled} />
        <Row className="justify-content-center">
        <Col md="8">
            <ListGroup>
              {list}
            </ListGroup>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default Dashboard;
