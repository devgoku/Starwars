import React from "react";
//import axios from "axios";

import {
  Card,
  CardBody,
  CardGroup,
  Row,
  Col,
  Form,
  Input,
  InputGroup
} from "reactstrap";

const search = (props) => { 
    return (
      <Row className="justify-content-center">
        <Col md="8">
          <CardGroup>
            <Card className="p-4">
              <CardBody>
                <Form>
                  <h1>Search Planet</h1>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      placeholder="Search planet by name"
                      onChange ={props.changes}
                      disabled = {props.disabled}
                      />
                  </InputGroup>
                </Form>
              </CardBody>
            </Card>
          </CardGroup>
        </Col>
      </Row>
    );
}

export default search;
